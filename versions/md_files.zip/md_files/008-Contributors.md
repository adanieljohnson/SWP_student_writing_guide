# Contributors {-}

The __SWP Writing Resource Guide__ is the product of many collaborators and contributors. 

__Project Manager & Lead Author__ 

* A. Daniel Johnson, Teaching Professor, Dept. Biology, Wake Forest University, Winston-Salem NC

__Principle Contributors__ 

* Shannon Mallison, Lab Program Manager, Dept. Biology, Wake Forest University (Structure of original guide, content author, co-designer of bins scoring model)
* Sabrina Setaro, Data Scientist, Compact Power Equipment Inc., York SC (Co-designer of bins scoring model)

__Other Contributors__

* MJ Carmichael, Asst. Professor Biology, Hollins University, Roanoke VA (Co-author of statistics section)
* Kyle Luth, Explorations in Alternative Energies Teacher, Winston-Salem/Forsyth County Schools, NC (Co-author of statistics section)
* T. Ryan Price, Data Scientist and Project Manager, STEM Writing Project, Wake Forest University



