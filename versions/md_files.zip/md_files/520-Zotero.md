# Coming Soon: Using Zotero {#zotero520}

We are looking for an author for this page, or someone who can contribute existing materials they have written. The text will be published under a Creative Commons 4.0 BY/NC/SA license, and copyright will remain with the original author.

## What IS Zotero {-}


## How to Get Zotero {-}


## Adding References to Zotero {-}


## Citing References Using Zotero {-}


## Making a Literature Cited Section {-}


